# Irfan&Co — Portfolio Website

A single self-contained file (`index.html`) — all HTML, CSS, JavaScript and imagery (inline SVG) live inside it. No build step, no dependencies to install. Built on the Irfan&Co brand system (Ink / Clay / Paper / Stone; Space Grotesk + Inter + Space Mono).

---

## 1. Put it live on GitHub Pages

1. Create a repo (e.g. `irfanco-site`) and drop `index.html` at the **root**.
2. Repo → **Settings → Pages**.
3. Under *Build and deployment → Source*, choose **Deploy from a branch**, branch `main`, folder `/ (root)`. Save.
4. Wait ~1 minute. Your site is at `https://<username>.github.io/irfanco-site/`.

### Use your own domain (irfanco.com)
1. In **Settings → Pages → Custom domain**, enter `irfanco.com` and save (this adds a `CNAME` file).
2. At your domain registrar, add DNS records:
   - Four `A` records pointing `@` to `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - One `CNAME` record for `www` → `<username>.github.io`
3. Back in Pages, tick **Enforce HTTPS** once the certificate is issued.

---

## 2. Add your photo (the founder portrait)

The Studio section shows a drawn silhouette by default. To use your real photo:

- Name a photo **`founder.jpg`** and put it in the **same folder** as `index.html`.
- That's it — it swaps in automatically. If the file is missing, the silhouette shows instead (no broken image).
- Portrait area is 4:5; a ~1000×1250px image looks best.

---

## 3. Wire up the contact form

The form currently points at a placeholder. **Until you connect it, submissions open the visitor's email app to `hello@irfanco.com`** — nothing is lost, but connecting a form service is better.

**Formspree (free tier, ~2 min):**
1. Sign up at [formspree.io](https://formspree.io), create a form, copy its endpoint (looks like `https://formspree.io/f/abcdwxyz`).
2. In `index.html`, find:
   ```html
   <form ... action="https://formspree.io/f/your-form-id" ...>
   ```
   Replace `your-form-id` with your real ID.
3. Done. Submissions now show an inline "Brief received" message and land in your inbox.

*(Getform, Basin, or Web3Forms work the same way — just paste their POST URL into `action`.)*

---

## 4. Swap in your real work

Each card in the **Work** section is a link. In `index.html`, find the `grid-work` block. For each `<a class="wcard" ...>`:
- Change `href="https://vimeo.com/irfanismailm"` to the specific Vimeo video URL.
- Edit the `<h3>` title, the `wcard__cat` category, and the `wcard__tc` timecode.
- The thumbnail is an inline `<svg>` — replace the whole `<svg>…</svg>` with an `<img src="thumbs/yourfile.jpg" ...>` if you'd rather use real stills.

The two big buttons under the grid point to your Vimeo and Behance — already set to `irfanismailm`.

---

## 5. Quick edits

| What | Where in `index.html` |
|---|---|
| **Stat numbers** (8 / 140+ / 45+ / 2) | `class="stat"` blocks — change `data-to="…"` and the labels |
| **Headline & copy** | Plain text in each `<section>` |
| **Email / Instagram / WhatsApp** | The `details` block in the Contact section + the footer |
| **Founder name** | Search `Irfan · Founder` and `— Irfan, Founder` (I didn't assume a surname — add yours) |
| **Brand colours** | The `:root { … }` block at the top of the `<style>` |
| **Marquee words** | The `marquee__row` spans |

---

## Notes

- **Fonts** load from Google Fonts, so the live site needs internet (it always has it when hosted). If a font ever fails, the site falls back to clean system fonts.
- **WhatsApp** is shown as the username `irfanandco` (your reserved handle). Once your WhatsApp Business number is live, you can turn it into a click-to-chat link: `https://wa.me/<full number>`.
- **Accessibility & motion**: keyboard focus is visible, and all animation is disabled automatically for visitors who set "reduce motion".
- Responsive across mobile / tablet / desktop / widescreen; the nav collapses to a full-screen menu under 768px.
